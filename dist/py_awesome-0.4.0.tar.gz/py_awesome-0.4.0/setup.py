from setuptools import setup, find_packages

setup(
    name='py_awesome',
    version='0.4.0',
    packages=find_packages(""),
    install_requires=[
        'pygame'
    ],
    entry_points={
        'console_scripts': [
            'gen = py_awesome.gen:gen'
        ]
    },
    # add folder
    package_data={'py_awesome': ['game/*']},
    include_package_data=True
)