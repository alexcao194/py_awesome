def log(tag, msg):
    print(tag.__class__.__name__ + ": " + msg)