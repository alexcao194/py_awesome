from setuptools import setup, find_packages

setup(
    name='py_awesome',
    version='0.3',
    packages=find_packages(),
    install_requires=[
        'pygame'
    ],
    entry_points={
        'console_scripts': [
            'gen = py_awesome.gen:gen'
        ]
    }
)